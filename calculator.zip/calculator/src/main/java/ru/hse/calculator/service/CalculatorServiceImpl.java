package ru.hse.calculator.service;

import org.springframework.stereotype.Service;
import ru.hse.calculator.exception.DivideByZeroException;

@Service
public class CalculatorServiceImpl implements CalculatorService {
    @Override
    public double add(double lhv, double rhv) {
        return lhv + rhv;
    }

    @Override
    public double sub(double lhv, double rhv) {
        return lhv - rhv;
    }

    @Override
    public double multiply(double lhv, double rhv) {
        return lhv * rhv;
    }

    @Override
    public double divide(double lhv, double rhv) {
        if (rhv == 0) {
            throw new DivideByZeroException();
        }
        return lhv / rhv;
    }
}
