package ru.hse.calculator.controller;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.hse.calculator.api.CalculatorApi;
import ru.hse.calculator.service.CalculatorService;

@RestController
@AllArgsConstructor
public class CalculatorController implements CalculatorApi {
    private CalculatorService calculatorService;
    @Override
    @GetMapping("/add")
    public double add(@RequestParam double lhv, @RequestParam double rhv) {
        return calculatorService.add(lhv, rhv);
    }

    @Override
    @GetMapping("/sub")
    public double sub(@RequestParam double lhv, @RequestParam double rhv) {
        return calculatorService.sub(lhv, rhv);
    }

    @Override
    @GetMapping("/multiply")
    public double multiply(@RequestParam double lhv, @RequestParam double rhv) {
        return calculatorService.multiply(lhv, rhv);
    }

    @Override
    @GetMapping("/divide")
    public double divide(@RequestParam double lhv, @RequestParam double rhv) {
        return calculatorService.divide(lhv, rhv);
    }
}
