package ru.hse.calculator.service;

public interface CalculatorService {
    double add(double lhv, double rhv);

    double sub(double lhv, double rhv);

    double multiply(double lhv, double rhv);

    double divide(double lhv, double rhv);
}
