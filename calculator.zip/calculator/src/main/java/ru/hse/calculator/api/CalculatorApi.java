package ru.hse.calculator.api;

public interface CalculatorApi {
    double add(double lhv, double rhv);

    double sub(double lhv, double rhv);

    double multiply(double lhv, double rhv);

    double divide(double lhv, double rhv);

}
