package ru.hse.calculator.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class CalculatorServiceTest {
    private CalculatorService calculatorService = new CalculatorServiceImpl();
    @Test
    void add__success() {
        var add = calculatorService.add(2, 2);

        assertEquals(4, add);
    }
    @Test
    void mult__success() {
        var add = calculatorService.multiply(2, 3);

        assertEquals(6, add);
    }
}
