package ru.hse.calculator.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.hse.calculator.api.CalculatorApi;
import ru.hse.calculator.service.CalculatorService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CalculatorControllerTest {

    @Mock
    private CalculatorService calculatorService;
    @InjectMocks
    private CalculatorController calculatorApi;

    @Test
    void add__serviceIsCalled() {
        when(calculatorService.add(1, 2)).thenReturn(3d);
        double add = calculatorApi.add(1, 2);

        assertEquals(3, add);

        verify(calculatorService, times(1)).add(1, 2);
    }
}
